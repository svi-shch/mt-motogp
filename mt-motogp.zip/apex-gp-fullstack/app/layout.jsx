import './globals.css';

export const metadata = {
  title: 'MT — MotoGP Race Intelligence',
  description: 'MotoGP race intelligence dashboard: weather, rider profiles, race history and transparent forecasts.',
  applicationName: 'MT'
};

export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
